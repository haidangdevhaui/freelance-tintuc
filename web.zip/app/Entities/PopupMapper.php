<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class PopupMapper extends Model
{
    public $timestamp = false;
}
