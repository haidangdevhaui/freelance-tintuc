<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class Permisions extends Model
{
    //
}
