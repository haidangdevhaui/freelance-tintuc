<?php 

return [
	[
		'name' => 'Sống chất',
		'icon' => '',
	],
	[
		'name' => 'Góc nhìn',
		'icon' => '',
	],
	[
		'name' => 'Tin lên kệ',
		'icon' => '',
	],
	[
		'name' => 'Sáng tạo',
		'icon' => '',
	],
	[
		'name' => 'Công nghệ',
		'icon' => '',
	],
	[
		'name' => 'Giải trí',
		'icon' => '',
	],
	[
		'name' => 'Phóng sự ảnh',
		'icon' => '',
	]

];