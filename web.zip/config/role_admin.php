<?php
return [
    0 => 'Cộng tác viên',
    1 => 'Admin Master',
    2 => 'Phóng viên',
    3 => 'Biên tập',
];
