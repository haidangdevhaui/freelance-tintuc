<?php 

return [
	"home" => [
		[
			"value" => 1,
			"name"  => "Bên dưới slider (765 x 88)"
		],
		[
			"value" => 2,
			"name"  => "Bên dưới danh mục SỐNG CHẤT (765 x 88)"
		],
		[
			"value" => 3,
			"name"  => "Bên dưới danh mục TIN LÊN KỆ (765 x 88)"
		],
		[
			"value" => 4,
			"name"  => "Bên dưới danh mục GÓC NHÌN - SÁNG TẠO (765 x 88)"
		],
		[
			"value" => 5,
			"name"  => "Bên dưới box tin cạnh Slider (300 x 250)"
		],
		[
			"value" => 6,
			"name"  => "Bên dưới danh mục PHÓNG SỰ ẢNH (300 x 600)"
		]
	],
	"category" => [
		[
			"value" => 7,
			"name" => "Bên dưới Slider (764 x 88)"
		],
		[
			"value" => 8,
			"name" => "Bên phải Slider (300 x 220)"
		],
		[
			"value" => 9,
			"name" => "Bên dưới box Mới nhất - Đọc nhiều (300 x 250)"
		],
		[
			"value" => 10,
			"name" => "Bên dưới 4 tin đầu (764 x 88)"
		],
	],
	"sub_category" => [
		[
			"value" => 11,
			"name" => "Bên dưới Slider (764 x 88)"
		],
		[
			"value" => 10,
			"name" => "Bên dưới 4 tin đầu (764 x 88)"
		],
		[
			"value" => 9,
			"name" => "Bên dưới box Mới nhất - Đọc nhiều (300 x 250)"
		]
	],
	"detail" => [
		[
			"value" => 14,
			"name" => "Bên trên box Mới nhất - Đọc nhiều (300 x 250)"
		],
		[
			"value" => 15,
			"name" => "Bên dưới box Có thể bạn quan tâm (300 x 600)"
		]
	],
	"mobile_detail" => [
		[
			"value" => 16,
			"name" => "Popup"
		],
		[
			"value" => 17,
			"name" => "Catfish"
		],
		[
			"value" => 18,
			"name" => "In page"
		]
	]
];