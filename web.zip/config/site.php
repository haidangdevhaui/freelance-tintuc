<?php

return [
	'title' => 'Tin tức'
];