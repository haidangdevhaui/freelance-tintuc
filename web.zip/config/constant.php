<?php 

return [
	'fixed_timer' => 180,
	'fixed_type' => [
		1 => 'Chỉ hiển thị ở trang 1 danh mục cấp 1',
		2 => 'Chỉ hiển thị ở trang 1 danh mục cấp 2',
		3 => 'Vị trí top 1',
		4 => 'Vị trí top 2-5',
	]
];